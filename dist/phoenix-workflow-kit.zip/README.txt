﻿# AI Workflow - share kit

1. Open  phoenix-workflow-pamphlet.html  in a browser. Read the philosophy (~5 min).
2. Copy the implementation prompt (button in the pamphlet, or implementation-prompt.md).
3. Paste it into WHATEVER AI you use, and attach  phoenix-workflow-framework.zip.
4. Answer its questions - it maps the framework's roles onto your own AIs and takes only what fits.

Paths inside are placeholders (C:\Users\<you>\...) and the operator is generalized as 'the user' -
your AI rewrites both for your machine.
